# Rádio Embarcada — Instruções para Agentes

## Objetivo do projeto

Este projeto é uma plataforma de rádio embarcada destinada inicialmente a motoristas de aplicativos locais de mobilidade.

O produto deve permitir que várias empresas utilizem o mesmo aplicativo Android, cada uma com sua própria identidade visual, programação, vinhetas, jingles e campanhas.

A arquitetura deve ser preparada para crescimento futuro, incluindo Android Auto, múltiplos clientes, gerenciamento remoto da programação e possível integração futura com aplicativos de mobilidade.

## Princípios fundamentais

1. O aplicativo deve ser simples para o motorista.
2. O motorista não deve precisar montar playlists.
3. A programação da rádio é automática.
4. Cada empresa possui sua própria rádio.
5. O mesmo aplicativo atende vários clientes.
6. A configuração deve vir do servidor.
7. O player deve continuar funcionando em segundo plano.
8. A reprodução deve ser adequada ao ambiente automotivo.
9. O projeto deve nascer preparado para Android Auto.
10. Não implementar funcionalidades desnecessárias ao MVP.

## Plataforma inicial

- Android
- Kotlin
- Jetpack Compose
- AndroidX Media3
- ExoPlayer
- MediaSession
- MediaLibraryService
- Foreground Service quando necessário
- Integração futura com Android Auto

Evitar bibliotecas de player paralelas sem necessidade.

## Arquitetura multi-tenant

O aplicativo é único.

Cada empresa é considerada um tenant ou cliente.

Cada tenant poderá ter:

- ID
- nome
- código de ativação
- logotipo
- cores
- nome da rádio
- stream próprio
- vinhetas próprias
- jingles próprios
- campanhas próprias
- configurações de reprodução

O aplicativo deve carregar essas informações dinamicamente.

Não criar APK separado para cada cliente.

## Ativação da rádio

No primeiro acesso o motorista deverá informar um código fornecido pela empresa.

Exemplo: `ALCE2026`

O aplicativo consulta a API e recebe a configuração do cliente.

Exemplo conceitual:

```json
{
  "clientId": "alce",
  "name": "Alce App Transporte",
  "radioName": "Rádio Alce",
  "logoUrl": "https://exemplo.com/logo.png",
  "primaryColor": "#000000",
  "streamUrl": "https://radio.exemplo.com/alce"
}
```

A configuração poderá ser armazenada localmente para evitar novo login a cada abertura.

## Programação

O aplicativo não controla a programação musical.

A programação deve ser produzida no servidor.

O servidor poderá organizar músicas, vinhetas, jingles, publicidade e avisos institucionais seguindo regras previamente configuradas.

O aplicativo recebe apenas o stream final da estação.

## Rádio 24/7

Cada cliente terá sua própria transmissão.

O aplicativo deve ser capaz de:

- iniciar o stream
- pausar
- continuar
- recuperar reprodução após perda temporária de internet
- reagir corretamente a troca de rede
- manter reprodução em segundo plano

## Player

O player deve usar Media3.

A lógica de reprodução deve ficar separada da interface.

Criar módulos ou classes bem definidos para:

- Player
- MediaSession
- configuração da estação
- API
- armazenamento local
- interface

A UI nunca deve controlar diretamente detalhes internos do ExoPlayer.

Criar uma camada de abstração para o player.

## Reconexão

Conexões móveis podem oscilar.

A rádio deve tentar se recuperar automaticamente após perda temporária de internet.

Evitar loops agressivos de reconexão.

Implementar estratégia de retry/backoff quando adequado.

Mostrar estados simples:

- Conectando...
- Ao vivo
- Sem conexão
- Reconectando...

## Interface

A interface deve priorizar simplicidade e segurança.

Tela principal esperada:

- logotipo do cliente
- nome da rádio
- indicador AO VIVO
- botão Play/Pause
- nome do conteúdo atual quando disponível
- status da conexão

Evitar menus complexos, listas extensas, controles pequenos, excesso de informações e elementos que exijam atenção durante a condução.

## Android Auto

Desde o início a arquitetura deve permanecer compatível com Android Auto.

Preparar:

- MediaSession
- MediaLibraryService
- metadados de mídia
- controles padrão: play, pause e stop

Não criar interface automotiva customizada fora das APIs permitidas.

A implementação completa do Android Auto não é obrigatória na primeira tarefa, mas nenhuma decisão arquitetural deve dificultá-la posteriormente.

## Bluetooth

O aplicativo deve reproduzir normalmente através do sistema de áudio Android.

Não criar lógica proprietária de Bluetooth se não for necessária.

A saída de áudio será gerenciada pelo sistema Android.

## Áudio

O aplicativo deve respeitar:

- Audio Focus
- interrupções por chamadas
- outros players
- conexão/desconexão de dispositivos de áudio

Quando necessário, utilizar as APIs padrão do Android e do Media3.

## Backend

Não implementar backend definitivo durante a primeira etapa.

Durante o MVP inicial podem ser utilizados configuração mockada, JSON local ou endpoint de teste.

O backend futuro deverá permitir clientes, códigos de ativação, configuração visual, URLs das rádios, campanhas, status e permissões.

## Segurança

Nunca incluir no código senhas, chaves privadas, tokens permanentes, credenciais de banco ou secrets.

Usar variáveis de ambiente, configuração segura ou secret management quando necessário.

## Organização do código

Preferir arquitetura simples e clara.

Separar pelo menos:

```text
ui/
player/
data/
network/
model/
storage/
```

Não criar abstrações excessivas sem necessidade.

## Regras para alterações

Antes de implementar uma mudança relevante:

1. Ler este arquivo.
2. Ler `docs/MVP.md`.
3. Inspecionar a arquitetura atual.
4. Preservar funcionalidades existentes.
5. Implementar somente o necessário para a tarefa.
6. Rodar testes.
7. Rodar o build.
8. Corrigir erros antes de encerrar a tarefa.
9. Documentar decisões arquiteturais importantes.

## Primeira implementação

A primeira implementação deve focar somente em:

- projeto Android compilável
- Kotlin
- Jetpack Compose
- Media3
- player funcional
- reprodução de stream de teste
- reprodução em segundo plano
- MediaSession
- MediaLibraryService
- base preparada para Android Auto
- configuração mockada de um cliente

Não implementar ainda:

- backend definitivo
- painel administrativo
- sistema de publicidade
- relatórios
- cobrança
- catálogo musical
- múltiplas rádios reais em produção
