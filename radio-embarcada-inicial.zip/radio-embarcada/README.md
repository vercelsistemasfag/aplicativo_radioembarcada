# Rádio Embarcada

Aplicativo Android multi-tenant para reprodução de rádios 24/7 destinadas a plataformas locais de mobilidade.

## Estado

Projeto em fase inicial de MVP.

## Documentação

- `AGENTS.md` — regras e diretrizes para desenvolvimento.
- `docs/MVP.md` — escopo e requisitos do MVP.

## Stack prevista

- Kotlin
- Jetpack Compose
- AndroidX Media3
- ExoPlayer
- MediaSession
- MediaLibraryService
- Android Auto

## Objetivo inicial

Construir um player Android simples e confiável capaz de reproduzir um stream contínuo em segundo plano e carregar a identidade de diferentes clientes a partir de configuração.

## Desenvolvimento

Antes de alterar o projeto, leia:

1. `AGENTS.md`
2. `docs/MVP.md`

A primeira implementação deve permanecer focada no player e na base multi-tenant.
