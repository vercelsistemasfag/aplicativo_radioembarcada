# MVP — Rádio Embarcada

## Visão do produto

A Rádio Embarcada é uma plataforma de áudio para aplicativos locais de mobilidade.

O produto será fornecido como um único aplicativo Android multi-tenant. Cada empresa utilizará sua própria identidade visual e sua própria estação, sem necessidade de manter um APK separado por cliente.

A programação será contínua, automática e transmitida 24 horas por dia.

## Público inicial

Motoristas de aplicativos locais de mobilidade.

O motorista instala o aplicativo, ativa a rádio da empresa usando um código e reproduz a transmissão pelo sistema de áudio do veículo, Bluetooth ou Android Auto.

## Proposta do MVP

Validar quatro pontos:

1. reprodução estável de rádio por streaming no Android;
2. funcionamento em segundo plano;
3. carregamento de configuração por cliente;
4. arquitetura compatível com Android Auto.

## Escopo da primeira versão

### Incluído

- aplicativo Android
- Kotlin
- Jetpack Compose
- AndroidX Media3
- ExoPlayer
- MediaSession
- MediaLibraryService
- reprodução de stream HTTP/HTTPS
- play/pause
- status da transmissão
- reprodução em segundo plano
- notificação de mídia
- tratamento básico de Audio Focus
- reconexão após falha de rede
- configuração mockada de tenant
- identidade visual carregável por configuração
- persistência local básica
- estrutura preparada para Android Auto

### Fora do MVP inicial

- painel web administrativo
- criação automática de programação
- servidor de streaming definitivo
- sistema de publicidade
- relatórios de campanhas
- faturamento
- gerenciamento avançado de usuários
- Android Automotive OS
- iOS

## Experiência do motorista

### Primeiro acesso

1. Abrir aplicativo.
2. Informar código da empresa.
3. Aplicativo identifica o tenant.
4. Aplicativo salva a configuração localmente.
5. Tela da rádio é exibida.

### Tela principal

Elementos:

- logo da empresa
- nome da rádio
- indicador `AO VIVO`
- título do conteúdo atual quando disponível
- botão Play/Pause
- estado da conexão

Estados possíveis:

- Conectando
- Ao vivo
- Pausado
- Sem conexão
- Reconectando

## Multi-tenant

O mesmo aplicativo atende todos os clientes.

Configuração mínima por tenant:

```json
{
  "clientId": "alce",
  "activationCode": "ALCE2026",
  "companyName": "Alce App Transporte",
  "radioName": "Rádio Alce",
  "logoUrl": "https://exemplo.com/logo.png",
  "primaryColor": "#000000",
  "streamUrl": "https://radio.exemplo.com/alce",
  "enabled": true
}
```

No MVP essa configuração pode ser mockada.

A arquitetura deve permitir substituir o mock por API posteriormente sem reescrever o player.

## Programação da rádio

A programação não será montada no aplicativo.

O aplicativo recebe um stream contínuo pronto.

Modelo futuro:

```text
Biblioteca musical
       ↓
Motor de programação
       ↓
Músicas + vinhetas + jingles
       ↓
Encoder/servidor de streaming
       ↓
URL da estação
       ↓
Aplicativo Android
       ↓
Som do veículo
```

## Diretrizes musicais futuras

A rádio terá programação única e automática.

A curadoria deverá priorizar músicas ambientes e democráticas:

- sem baixo calão
- sem conteúdo sexual explícito
- sem conteúdo excessivamente agressivo
- sem graves excessivos
- sem áudio estridente
- sem grandes variações de volume
- adequada a passageiros de perfis diversos

Não haverá seleção de gênero pelo motorista no MVP.

## Programação comercial futura

O motor de programação poderá inserir automaticamente vinhetas institucionais, jingles, publicidade local, avisos e campanhas por horário.

Cada cliente terá sua própria programação comercial.

## Requisitos do player

O player deve:

- reproduzir stream contínuo
- funcionar com tela apagada
- manter MediaSession ativa
- mostrar notificação de mídia
- respeitar Audio Focus
- responder a controles de headset/veículo
- retomar após interrupções quando apropriado
- tentar reconectar automaticamente
- evitar consumo excessivo de bateria
- evitar múltiplas instâncias de player

## Android Auto

O projeto deve nascer preparado para Android Auto.

A primeira versão deve utilizar:

- MediaSession
- MediaLibraryService
- metadados compatíveis

A interface automotiva deve utilizar os padrões permitidos pelo Android Auto.

## Estratégia de rede

O aplicativo precisa considerar 4G, 5G, Wi‑Fi, perda temporária de sinal e troca entre redes.

Usar retry com backoff.

Não criar reconexão contínua agressiva.

## Persistência local

Salvar localmente:

- tenant ativo
- configuração visual
- URL da estação
- último estado relevante
- preferências básicas

Evitar armazenar dados sensíveis sem necessidade.

## Estrutura inicial sugerida

```text
app/
  src/main/java/.../
    ui/
    player/
    data/
    network/
    model/
    storage/
```

## Critérios de aceite da primeira etapa

A primeira entrega é considerada válida quando:

1. o projeto compila;
2. o app abre sem erro;
3. um stream de teste pode ser reproduzido;
4. play/pause funciona;
5. o áudio continua em segundo plano;
6. a notificação de mídia funciona;
7. MediaSession funciona;
8. MediaLibraryService está configurado;
9. a arquitetura não bloqueia Android Auto;
10. existe configuração mockada de pelo menos um tenant;
11. não existem credenciais hardcoded;
12. o README explica como executar o projeto.

## Próximas etapas após o MVP

1. API real de tenants
2. servidor de programação
3. streaming 24/7
4. painel administrativo
5. Android Auto completo
6. campanhas e jingles
7. métricas e relatórios
8. gerenciamento de licenças por cliente
