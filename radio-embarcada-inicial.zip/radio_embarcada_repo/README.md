# Rádio Embarcada

Aplicativo Android multi-tenant para rádios 24/7 voltadas a plataformas locais de mobilidade.

## Documentação
- `AGENTS.md` — instruções permanentes para agentes e Codex.
- `docs/MVP.md` — escopo e requisitos do MVP.

## Stack prevista
- Kotlin
- Jetpack Compose
- AndroidX Media3
- ExoPlayer
- MediaSession
- MediaLibraryService
- Android Auto

## Objetivo inicial
Construir um player Android simples, confiável e multi-tenant, capaz de reproduzir um stream contínuo em segundo plano.

## Antes de desenvolver
Leia:
1. `AGENTS.md`
2. `docs/MVP.md`
